import java.util.NoSuchElementException;

/**
   An implementation of a queue as a circular array.
*/
public class CircularArrayQueue
{
   private Object[] elements;
   //private data
   private int currentSize;
   private int head;
   private int tail;


   /**
      Constructs an empty queue.
   */
  public CircularArrayQueue()
  {
      final int INITIAL_SIZE = 10;
      elements = new Object[INITIAL_SIZE];
      
    }
  





   /**
      Checks whether this queue is empty.
      @return true if this queue is empty
   */




   /**
      Adds an element to the tail of this queue.
      @param newElement the element to add
   */





   /**
      Removes an element from the head of this queue.
      @return the removed element
   */





   /**
      Grows the element array if the current size equals the capacity.
   */





}//CircularArrayQueue

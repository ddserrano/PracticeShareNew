import java.util.NoSuchElementException;

/**
   An implementation of a stack as a sequence of nodes.
*/
public class LinkedListStack
{
   private Node first;
//First = the last guy added
   /**
      Constructs an empty stack.
   */
   public LinkedListStack()
   {
      first = null;
   }

   /**
      Adds an element to the top of the stack.
      @param element the element to add
   */

  public void push(Object o)
  {
      //Make new Node
      Node newNode = new Node();
      //node = ?;
      //worry about data and next.
      newNode.data = o;
      newNode.next = first;
      first = newNode;
   
    }
    




   /**
      Removes the element from the top of the stack.
      @return the removed element
   */
public Object pop()
{   
    if (first == null)
    {
        throw new NoSuchElementException();
    }
    Object o = first.data;  
    first = first.next;
    return o;
}







   /**
      Checks whether this stack is empty.
      @return true if the stack is empty
   */



   class Node
   {
      public Object data;
      public Node next;
   }
}

/**
   A program that demonstrates the LinkedList class
*/
public class ListDemo
{
   public static void main(String[] args)
   {
          //create LinkedList and add to it
          LinkedList staff = new LinkedList();
        
          //LinkedListIterator iterator = staff.iterator();
          staff.addFirst("H");
          staff.addFirst("e");
           staff.addFirst("l");
            staff.addFirst("l");
            staff.addFirst("o");
            
         
           System.out.println( staff.size());
            
          staff.removeFirst();
    
         // System.out.println(staff.getFirst());
          // | in the comments indicates the iterator position
          ListIterator iterator = staff.listIterator();
          
          iterator.next(); //D|RHT
          iterator.next();//DR|HT
          
         
    
          // Add more elements after second element
          iterator.add("Janet"); //DRJ|HT
          iterator.add("Neha");
          
    
    
          // Remove last traversed element
          iterator.next();
          iterator.remove();
    
    
          // Print all elements
          iterator = staff.listIterator();
          while (iterator.hasNext())
          {
             System.out.print(iterator.next() + " ");
          }
          System.out.println();
          
   }
}

public class StackDemo
{
   public static void main(String[] args)
   {
      LinkedListStack s = new LinkedListStack();
      //.push()
      s.push("H");
      s.push("E");
      s.push("A");
      //while !empty .pop()
      System.out.print(s.pop());
      System.out.print(s.pop());
   }
}

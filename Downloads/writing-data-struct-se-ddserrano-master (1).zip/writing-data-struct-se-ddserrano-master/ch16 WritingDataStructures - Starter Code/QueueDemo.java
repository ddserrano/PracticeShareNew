public class QueueDemo
{
   public static void main(String[] args)
   {
      //CircularArrayQueue q = new CircularArrayQueue();
      LinkedListQueue q = new LinkedListQueue();
     
      //add to q
      q.add("Kevin");
      q.add("Brandon");
      q.add("Nimmi");
      q.add("Henry");
      q.add("David");
      //print
      System.out.println(q.remove());
      q.printTail();
      q.TailToHead();
      q.printTail();
      System.out.println(q.remove());
      q.remove();

   }
}

/**
   Add a method firstToLast to this implementation of a queue.
   The method moves the element at the head of the queue to
   the tail of the queue. The element that was second in line
   will now be at the head.
*/
public class LinkedListQueue
{
    //data
    private Node head;
    private Node tail; //I forgot about the last ref
   /**
      Constructs an empty queue.
   */
  
  public LinkedListQueue()
  {
      head = null;
      tail = null;
    }
 public void TailToHead()
 {
    Object o = tail.data; //grabs data at tail
    Node newNode = new Node(); //makes newnode
    newNode.next = head;//makes the newNode's next the head
    newNode = head;//This newNode is the head
    newNode.data = o;//sets the newNode's data as the tail's data
    //finds tail
    Node node = head;  //sets node to head
    while(node != tail)
    {
        node = node.next;
        //iterates thru the nodes, eventually grabs node before the tail
    }
    node.next = null; //makes the next null
    node = tail;   // sets this node to the tail
    }
    public void FirstToLast()
    {
        Object o = head.data;
        head.next = head;
        
        add(o);
        
    }
    public void printTail()
    {
       System.out.println(tail.data);
    }
   /**
      Checks whether this queue is empty.
      @return true if this queue is empty
   */
  public boolean empty()
  {
      if (head == null)
      {
          return true;
        }        
      return false;        
    }


   /**
      Adds an element to the tail of this queue.
      @param newElement the element to add
   */
  public void add(Object o)
  {
      if (head == null)
      {
          Node newNode = new Node();
          newNode.data = o;
          newNode.next = null;
          head = newNode;
          tail = newNode;
          return;
        }            
        Node newNode = new Node();
        tail.next = newNode; //previous tail points to the new node
        tail = newNode; // makes the node the new tail
        newNode.data = o; // the newNode points to the object
        newNode.next = null; //next is nothing
    }

 public String toString()
 {
     String result = "";
     while (!(empty()))
     {
         result += remove() + "\n";
        }
     return result;
    }
   /**
      Removes an element from the head of this queue.
      @return the removed element
   */

  public Object remove()
  {
      //Grab data out of head
      if (head == null)
      {
          return null;
        }
      Object o = head.data;
      head = head.next;
      //what if last node is removed
      if (head == null) //queue is empty
      {
          tail = null;
        }
      return o;
    }

   class Node
   {
      public Object data;
      public Node next;
   }
}

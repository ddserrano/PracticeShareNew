import java.util.NoSuchElementException;

/**
   A linked list is a sequence of nodes with efficient
   element insertion and removal. This class
   contains a subset of the methods of the standard
   java.util.LinkedList class.
*/
public class LinkedList
{
  private static Node first;
 private static Node node = first;
   /**
      Constructs an empty linked list.
   */
  public LinkedList()
  {
      first = null;
      
    }

  public Object get(int n)
  {
      
      return getNode(n).data;
    }
    public Node getNode( int n)
    {
        Node place = first;
        int count = 0;
        while (place != null && count <= n)
        {
            place = place.next;
            count++;
        }
        return place;
    }
    public boolean contains(Object o)
    {
        Node node = first;
        while (node != null)
        {
            if (node.data.equals(o))
                return true;
            node = node.next;
        }
        return false;
    }
   
    public void Set(int n, Object o )
    {
       getNode(n).data = o;     
    }
   /**
      Returns the first element in the linked list.
      @return the first element in the linked list
   */
  public void addFirst(Object element)
  {
      Node newNode = new Node();
      newNode.data = element;
      newNode.next = first;
      first = newNode;
    }

    public Object getFirst()
    {
        if (first == null) {throw new NoSuchElementException(); }
        //data is a reference to the object
        return first.data;
    }
/*
   /**
      Removes the first element in the linked list.
      @return the removed element
   */
  public Object removeFirst()
  {
      if (first == null){throw new NoSuchElementException(); }
      Object OK = first.data;
      first = first.next;
      return OK;
      
      
    }
  /*
  public int addLast(Object element)
  {
      Node newNode = new Node();
      newNode.
    }
*/

/*
 public int size()
 {
   int s = 0;
   Node current = first;
   while (current != null)
   {
       s++;
       current = current.next;
    }
    return s;
       
        
    }
    */
    public static int size()
    {
        Node node = first;
       int Count = size(node);
       return Count;
    }
    public static int size(Node node)
    {
        int count = 0;
        if (node != null)
        {
            count++;
            size(node.next);
        }
        return count;
    }


   /**
      Adds an element to the front of the linked list.
      @param element the element to add
   */





   /**
      Returns an iterator for iterating through this list.
      @return an iterator for iterating through this list
   */
  public LinkedListIterator listIterator()
  {
      
      return new LinkedListIterator();
    }





   //Class Node
   class Node
   {
       public Object data; //this object
       public Node next;
    }


   class LinkedListIterator implements ListIterator
   {
      //private data
      private Node position;
      private Node previous;
      private boolean isAfterNext;
      /**
         Constructs an iterator that points to the front
         of the linked list.
      */
     public LinkedListIterator()
     {
         position = null;
         previous = null;
         isAfterNext = false;      
        }
       


      /**
         Moves the iterator past the next element.
         @return the traversed element
      */
     public Object next()
     {
         
         if (!(hasNext()))
            {throw new NoSuchElementException();}
             
         previous = position; //Remember
         isAfterNext = true;
         
         if (position == null)
         {
             position = first; // I have not called next
            }
            else
            {
                position = position.next; 
            }
         
            return  position.data;         
        }
  /**
         Tests if there is an element after the iterator position.
         @return true if there is an element after the iterator position
      */
     public boolean hasNext()
     {
                 if (position == null)
                    {
                        return (first!=null);
                    }
                 else
                 {
                    return (position.next != null);
                }
        }


      /**
         Adds an element before the iterator position
         and moves the iterator past the inserted element.
         @param element the element to add
      */
     public void add(Object o)
     {
         if (position == null)//beginning of the list
         {
             addFirst(o);
             position = first;
            }
            else
            {
                Node newNode = new Node();
                newNode.data = o; //Alias
                newNode.next = position.next; // I know who is next
                position.next = newNode; // Iterator thinks next is me
                position = newNode;
            }
         isAfterNext = false;
         
        }


      /**
         Removes the last traversed element. This method may
         only be called after a call to the next() method.
      */
     public void remove()
     {
         if (!isAfterNext)
         {
             throw new IllegalStateException();
            }
         if (position == first)
         {
             removeFirst();
            }
            else
            {
                previous.next = position.next;//move ref of previous to node
                //after me                
            }
            position = previous;
            isAfterNext = false;//You can't do remove again
            //first call to remove the current position reverts to 
            //the predecessor of removed element
            
        }

      /**
         Sets the last traversed element to a different value.
         @param element the element to set
      */
     public void set(Object element)
     {
         if(!isAfterNext)         
         {
             throw new IllegalStateException();
            }
            position.data = element;
        }
   }//LinkedListIterator
}//LinkedList
